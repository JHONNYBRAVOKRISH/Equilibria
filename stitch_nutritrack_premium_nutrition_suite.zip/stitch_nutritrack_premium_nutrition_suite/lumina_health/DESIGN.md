---
name: Lumina Health
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#404943'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#707973'
  outline-variant: '#bfc9c1'
  surface-tint: '#2c694e'
  primary: '#0f5238'
  on-primary: '#ffffff'
  primary-container: '#2d6a4f'
  on-primary-container: '#a8e7c5'
  inverse-primary: '#95d4b3'
  secondary: '#595d78'
  on-secondary: '#ffffff'
  secondary-container: '#dbdeff'
  on-secondary-container: '#5d617d'
  tertiary: '#274f3d'
  on-tertiary: '#ffffff'
  tertiary-container: '#3f6754'
  on-tertiary-container: '#b8e3cb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b1f0ce'
  primary-fixed-dim: '#95d4b3'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#0e5138'
  secondary-fixed: '#dee0ff'
  secondary-fixed-dim: '#c1c4e5'
  on-secondary-fixed: '#161a32'
  on-secondary-fixed-variant: '#414560'
  tertiary-fixed: '#c1ecd4'
  tertiary-fixed-dim: '#a5d0b9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#274e3d'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-padding: 32px
  gutter: 24px
  section-gap: 48px
---

## Brand & Style
The design system is engineered for a premium health-tech experience, blending high-performance data tracking with a serene, high-end aesthetic. The target audience consists of health-conscious professionals who value precision, clarity, and a sophisticated interface that feels more like a wellness retreat than a spreadsheet.

The visual style is **Modern Glassmorphism**. It utilizes multi-layered translucency, high-end background blurs, and organic depth to create a sense of lightness and "breathable" space. The emotional response is one of calm control and professional reliability—reducing the cognitive load of nutritional tracking through visual softness and spatial harmony.

## Colors
The palette is rooted in a "Health Tech" aesthetic, utilizing varying depths of green to signify growth and vitality. 

- **Primary & Tertiary:** Vibrant Mint (#2D6A4F) serves as the primary action color, while Deep Forest Green (#1B4332) provides grounding for high-contrast text and branding elements.
- **Secondary:** Soft Slate (#4A4E69) is used for analytical components and secondary metadata to provide a professional, neutral counterpoint to the greens.
- **Macros:** Specific functional colors are reserved for nutrient tracking: Protein (Blue), Carbs (Yellow), and Fat (Red). These should be used with a slightly desaturated "premium" profile.
- **Surfaces:** The background is an Off-white Sage (#F8F9FA). Interactive panels use a glassmorphic white (70% opacity) with a `20px` backdrop-blur to maintain legibility over the soft background hues.

## Typography
Inter is utilized across the entire system for its mathematical precision and exceptional readability at both display and micro-copy sizes. 

- **Data Hierarchy:** Large `display-lg` weights are used for primary calorie totals and macro numbers, acting as the visual anchor of the dashboard.
- **Rhythm:** Tight letter-spacing on headings provides a more "designed" editorial feel.
- **Labels:** Use `label-sm` with slight tracking (letter-spacing) for macro identifiers and metadata categories to distinguish them from functional body text.

## Layout & Spacing
The layout follows a **Fluid Grid** model with generous white space to prevent the interface from feeling "clinical" or cluttered.

- **Desktop:** A 12-column grid with a `32px` margin. Key metrics are housed in glassmorphic cards that span 3, 4, or 6 columns.
- **Tablet:** 8-column grid with `24px` margins. 
- **Mobile:** Single column layout with `16px` margins. Top-level data points (calories) are pinned or given prominent vertical hierarchy.
- **Rhythm:** All spacing must be a multiple of `8px`. Use larger gaps (`48px+`) between major functional sections to allow the glassmorphic layers to "breathe."

## Elevation & Depth
Depth is the cornerstone of this design system. Rather than traditional shadows, we use a combination of physical and optical depth:

- **Surface Layers:** The base layer is the Off-white Sage background. The second layer consists of Glassmorphic panels with a `20px` backdrop-blur and a subtle `1px` inner stroke (white at 40% opacity) to simulate the edge of a glass pane.
- **Shadows:** Use multi-layered ambient shadows. A "Deep" shadow for floating elements consists of:
    1. A sharp, low-opacity drop shadow (0px 2px 4px rgba(0,0,0,0.05)).
    2. A wide, soft diffused shadow (0px 12px 32px rgba(0,0,0,0.08)).
- **Transitions:** Elevate cards on hover by increasing the shadow spread and reducing the background opacity of the glass effect slightly to 80%.

## Shapes
The shape language is organic and soft, avoiding sharp corners to maintain the wellness-focused brand identity.

- **Main Containers:** Use `rounded-xl` (24px) for all primary data cards and glassmorphic panels.
- **Buttons & Controls:** Use `rounded-lg` (16px) to create a approachable, tactile feel.
- **Macro Bars:** Progress bars must be fully pill-shaped (`rounded-full`) to emphasize the "fluid" nature of the tracking system.

## Components
- **Glassmorphic Panels:** These are the primary content carriers. They must include a `backdrop-filter: blur(20px)`, a semi-transparent white background, and a subtle inner border.
- **Circular Progress Rings:** Used for daily calorie goals. Use a thick `12px` stroke with a soft, rounded cap. The background track should be the Primary Green at 10% opacity.
- **Macro Progress Bars:** Horizontal bars with a `12px` height. Ensure high-contrast text labels are placed above the bar, not inside, to maintain a clean aesthetic.
- **Primary Buttons:** Styled with a subtle vertical gradient from Mint (#2D6A4F) to Forest Green (#1B4332). Apply a soft shadow that matches the button's hue rather than a neutral gray.
- **Input Fields:** Minimalist design. Use a white background with 40% opacity and a `2px` bottom border that illuminates in Mint (#2D6A4F) upon focus.
- **Custom Icons:** Use a custom 24px icon set with "duotone" styling—one part Forest Green, one part Mint—to reinforce the brand palette.